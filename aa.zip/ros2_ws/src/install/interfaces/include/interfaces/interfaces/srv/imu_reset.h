// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:srv/ImuReset.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__IMU_RESET_H_
#define INTERFACES__SRV__IMU_RESET_H_

#include "interfaces/srv/detail/imu_reset__struct.h"
#include "interfaces/srv/detail/imu_reset__functions.h"
#include "interfaces/srv/detail/imu_reset__type_support.h"

#endif  // INTERFACES__SRV__IMU_RESET_H_
